
-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
CREATE TABLE IF NOT EXISTS `entry` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Parentname` text NOT NULL,
  `Gender` text NOT NULL,
  `DOJ` text NOT NULL,
  `Time` varchar(255) NOT NULL,
  `Phonenumber` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Zipcode` varchar(255) NOT NULL,
  `YearofGraduation` text NOT NULL,
  `Comments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entry`
--

INSERT INTO `entry` (`id`, `Username`, `Email`, `Parentname`, `Gender`, `DOJ`, `Time`, `Phonenumber`, `Address`, `Zipcode`, `YearofGraduation`, `Comments`) VALUES
(8, 'irfana', 'irfusadhik@gmail.com', 'jaffer', '600021', '12/01/2018', '4 : 14 PM', '9003033840', '600021', '600021', '2019', 'yes'),
(9, 'irfana', 'irfusadhik@gmail.com', 'jaffer', '600021', '12/01/2018', '4 : 20 PM', '9003033840', '600021', '600021', '2019', 'yes'),
(10, 'irsadhiki', 'irfusadhik@gmail.com', 'sadhik', '600021', '12/01/2018', '4 : 33 PM', '9003033840', '600021', '600021', '2019', 're'),
(11, 'reta', 'irfusadhik@gmail.com', 'sad', '600021', '12/01/2018', '4 : 40 PM', '9003033840', '600021', '600021', '2019', 're'),
(12, 'irfana', 'iftcgc@gmail.com', 'urf', '600021', '12/28/2018', '4 : 51 PM', '9003033840', '600021', '600021', '2019', 're');
