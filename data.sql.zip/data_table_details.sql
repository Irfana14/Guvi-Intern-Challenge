
-- --------------------------------------------------------

--
-- Table structure for table `details`
--

DROP TABLE IF EXISTS `details`;
CREATE TABLE IF NOT EXISTS `details` (
  `Username` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact` int(255) NOT NULL,
  `student_address` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`Username`, `student_name`, `student_email`, `student_contact`, `student_address`) VALUES
('', 'irfaba', 'irfusadhik@gmail.com', 90303384, 'hello'),
('', 'irfu', 'rithu@gmail.com', 8909876, 'iuyht,\r\nold washer'),
('', 'irfaba', 'irfusadhik@gmail.com', 3456789, 'sdrefr');
