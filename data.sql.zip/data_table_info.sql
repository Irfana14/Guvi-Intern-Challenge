
-- --------------------------------------------------------

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE IF NOT EXISTS `info` (
  `Username` varchar(255) NOT NULL,
  `student_email` varchar(255) NOT NULL,
  `student_contact` int(255) NOT NULL,
  `student_address` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`Username`, `student_email`, `student_contact`, `student_address`) VALUES
('', 'irfusadhik@gmail.com', 8909876, 'xdcfv'),
('', 'fsdfdfgdfg', 43546, 'sdsfsdf'),
('', 'sdsdfsdf', 3453465, 'rgfdgdfg'),
('', 'xsccv', 899797, 'dcdvfvf'),
('', 'xsccv', 899797, 'dcdvfvf'),
('yuio', 'dgfdg', 23545, 'dcdvfvf');
