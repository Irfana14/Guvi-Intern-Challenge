
-- --------------------------------------------------------

--
-- Table structure for table `saffron`
--

DROP TABLE IF EXISTS `saffron`;
CREATE TABLE IF NOT EXISTS `saffron` (
  `Username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saffron`
--

INSERT INTO `saffron` (`Username`, `password`) VALUES
('irfana', 'asd'),
('reshma', 'shamina'),
('jaffer', 'tre'),
('sadhik', '6578'),
('sadhip', 'mnb'),
('ytr', 'cvb'),
('ytre', 'wrt'),
('rewq', '1234'),
('rewqmn', 'rtyu'),
('gdc', 'vbn'),
('erty', 'sdf'),
('rtyu', 'mkli'),
('eqit', 'dfgh'),
('wer', 'dfg'),
('rithu', 'asdf'),
('wdfg', 'qwer'),
('dfgh', '1234'),
('vbnm', 'asdf'),
('dfg', 'asd'),
('tyu', 'asdf'),
('lkjh', 'qwe'),
('yuio', 'kjh'),
('irsadhik', 'irsadhik'),
('irsadhiki', 'irsadhiki'),
('reta', 'reta'),
('retal', 'retal');
